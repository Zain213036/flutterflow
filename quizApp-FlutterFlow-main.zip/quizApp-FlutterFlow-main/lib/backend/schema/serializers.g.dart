// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'serializers.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializers _$serializers = (new Serializers().toBuilder()
      ..add(QuestionARecord.serializer)
      ..add(QuestionBRecord.serializer)
      ..add(QuestionCRecord.serializer)
      ..add(QuestionDRecord.serializer)
      ..add(QuizRecord.serializer)
      ..add(QuizSetRecord.serializer))
    .build();

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
